importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBcdgkzy7SSUTeU3mW3Y_XK3qJa8xmepdA",
    authDomain: "nmanager-4f504.firebaseapp.com",
    projectId: "nmanager-4f504",
    storageBucket: "nmanager-4f504.appspot.com",
    messagingSenderId: "363364443490",
    appId: "1:363364443490:web:05ebc9b78218e9e89ff83b",
    measurementId: "G-CK7BFJH8VG"
  };
firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function (payload) {
    console.log('Received background message ', payload);
    const notificationTitle = payload.notification.title;
    const notificationOptions = {
        body: payload.notification.body,
        icon: payload.notification.icon || '/firebase-logo.png' // Optional icon
    };

    self.registration.showNotification(notificationTitle, notificationOptions);
});
