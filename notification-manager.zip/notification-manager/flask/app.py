from flask import Flask, render_template, redirect, url_for, jsonify,request
from flask_sqlalchemy import SQLAlchemy
import json
import os
from firebase_admin import credentials, messaging
from firebase_admin import initialize_app
from sqlalchemy import text
from flask import send_from_directory
import requests
from google.oauth2 import service_account

from google.auth.transport.requests import Request


app = Flask(__name__)
SERVICE_ACCOUNT_FILE = 'C:\\Users\\hi\\Downloads\\Working\\Newfolder\\notification-manager\\nmanager-4f504-firebase-adminsdk-bnv75-0a2c1299f1.json'
SCOPES = ['https://www.googleapis.com/auth/firebase.messaging']
credential = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
credential.refresh(Request())
access_token = credential.token

app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:Vamshi2@localhost/vamshi'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
db=SQLAlchemy(app)
cred = credentials.Certificate("C:\\Users\\hi\\Downloads\\Working\\Newfolder\\notification-manager\\nmanager-4f504-firebase-adminsdk-bnv75-0a2c1299f1.json")
initialize_app(cred)
class User(db.Model):
    __tablename__ = 'users'
    userid = db.Column(db.Integer, primary_key=True)
    tokenid = db.Column(db.String(20), unique=True, nullable=False)

class Templates(db.Model):
    __tablename__='template'
    title=db.Column(db.String(20),primary_key=True)
    message=db.Column(db.String(100),unique=True,nullable=False)

class Notification(db.Model):
    __tablename__ = 'notifications'
    notification_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    users = db.Column(db.JSON, nullable=False)
    timestamp = db.Column(db.TIMESTAMP, server_default=db.func.current_timestamp(), nullable=False)

with app.app_context():
    db.create_all()

def read_json_data(file_path):
    with open(file_path,'r') as file:
        return json.load(file)

def send_notifications(title, message, user_ids):
    tokens = []
    format_strings = ','.join([':user_id' + str(i) for i in range(len(user_ids))])
    query = text(f"SELECT tokenid FROM users WHERE userid IN ({format_strings})")
    query = query.bindparams(**{f'user_id{i}': user_id for i, user_id in enumerate(user_ids)})
    users = db.session.execute(query).fetchall()

    tokens = [user[0] for user in users]

    if tokens:
        print(tokens)
        multicast_message = messaging.MulticastMessage(
            notification=messaging.Notification(
                title=title,
                body=message,
            ),
            tokens=tokens,
        )
        response = messaging.send_multicast(multicast_message)
        print("hello")
        print(response.success_count,response.failure_count)
        print("bye")
        return response.success_count, response.failure_count
        url = f'https://fcm.googleapis.com/v1/projects/{credential.project_id}/messages:send'

    # Headers
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json; UTF-8',
    }

    return 0, len(user_ids)


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico')


@app.route('/templatesfetchfromdb',methods=['GET'])
def temp_fetch():
    template=Templates.query.all()
    temp_list=[{'title':i.title,'message':i.message}for i in template]
    return jsonify(temp_list)


@app.route('/pushtemplatetodb', methods=['POST'])
def push_templates():
    json_data = request.get_json()
    for temp_data in json_data['template']:
        temp = Templates.query.filter_by(title=temp_data['title']).first()
        if temp:
            temp.message = temp_data['message']
        else:
            temp = Templates(title=temp_data['title'], message=temp_data['message'])
            db.session.add(temp)
    db.session.commit()
    return 'Data has been inserted/updated successfully.'


@app.route('/pushnotificationtodb', methods=['POST'])
def push_notifications():
    json_data = request.get_json()
    title = json_data['Title']
    message = json_data['Message']
    user_ids = json_data['users']

    notification = Notification(
        title=title,
        message=message,
        users=user_ids
    )
    db.session.add(notification)
    db.session.commit()

    success_count, failure_count = send_notifications(title, message, user_ids)

    return jsonify({
        'message': 'Notification has been inserted and sent successfully.',
        'success': success_count,
        'failure': failure_count
    })


@app.route('/notificationsfetchfromdb', methods=['GET'])
def fetch_notifications():
    notifications = Notification.query.all()
    notifications_list = [{
        'notification_id': notification.notification_id,
        'title': notification.title,
        'message': notification.message,
        'users': notification.users,
        'timestamp': notification.timestamp
    } for notification in notifications]
    return jsonify(notifications_list)

@app.route('/data')
def ind():
    return render_template('database.html')

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/selecteduser', methods=["GET"])
def users():
    with open('usernames.json', 'r') as f:
        gusers=json.load(f)
        final= jsonify(gusers)
    return final


@app.route('/user')
def user():
    with open('users.json', 'r') as b:
        gusers=json.load(b)
    return jsonify(gusers)


 
@app.route('/fetch', methods=['GET'])
def fetch_users():
    users = User.query.all()
    users_list = [{'userid': user.userid, 'tokenid': user.tokenid} for user in users]
    return jsonify(users_list)



@app.route('/push', methods=['POST'])
def push_users():
    json_data = request.get_json()
    for user_data in json_data['users']:
        user = User.query.filter_by(userid=user_data['userid']).first()
        if user:
            user.tokenid = user_data['tokenid']
        else:
            user = User(userid=user_data['userid'], tokenid=user_data['tokenid'])
            db.session.add(user)
    db.session.commit()
    return 'Data has been inserted/updated successfully.'



@app.route('/delete', methods=['POST'])
def delete_users():
    json_data = request.get_json()
    for user_data in json_data['users']:
        user = User.query.filter_by(userid=user_data['userid']).first()
        if user:
            db.session.delete(user)
    db.session.commit()
    return 'Data has been deleted successfully.'

 
@app.route('/firebase-messaging-sw.js')
def service_worker():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'firebase-messaging-sw.js')
if __name__==('__main__'):
    # Start the data pushing in a separate thread
    
    app.run(debug=True)