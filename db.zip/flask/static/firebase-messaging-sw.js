importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging.js');

const firebaseConfig = {
    apiKey: "AIzaSyC7AblT3fJA1rJG4C_uhTy26kCPJ7mmg2E",
    authDomain: "notification-manager-79659.firebaseapp.com",
    projectId: "notification-manager-79659",
    storageBucket: "notification-manager-79659.appspot.com",
    messagingSenderId: "968810201649",
    appId: "1:968810201649:web:d434b453948b03ae8d0b10",
    measurementId: "G-FV6RKJ816J"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
    console.log('[firebase-messaging-sw.js] Received background message ', payload);
    const notificationTitle = payload.notification.title;
    const notificationOptions = {
        body: payload.notification.body,
    };

    self.registration.showNotification(notificationTitle, notificationOptions);
});
