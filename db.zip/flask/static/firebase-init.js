// static/firebase-init.js

// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyC7AblT3fJA1rJG4C_uhTy26kCPJ7mmg2E",
    authDomain: "notification-manager-79659.firebaseapp.com",
    projectId: "notification-manager-79659",
    storageBucket: "notification-manager-79659.appspot.com",
    messagingSenderId: "968810201649",
    appId: "1:968810201649:web:d434b453948b03ae8d0b10",
    measurementId: "G-FV6RKJ816J"
};

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  const messaging = firebase.messaging();
  
  async function registerServiceWorker() {
    try {
      const serviceWorkerRegistration = await navigator.serviceWorker.register('/firebase-messaging-sw.js', {
        scope: '/firebase-cloud-messaging-push-scope'
      });
      console.log('Service Worker registered successfully:', serviceWorkerRegistration);
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }
  
  // Request permission to send notifications
  async function requestNotificationPermission() {
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        console.log('Notification permission granted.');
        const token = await messaging.getToken({ vapidKey: 'YOUR_PUBLIC_VAPID_KEY' });
        console.log('FCM Token:', token);
      } else {
        console.log('Unable to get permission to notify.');
      }
    } catch (error) {
      console.error('An error occurred while retrieving token:', error);
    }
  }
  
  // Register the service worker and request notification permission
  registerServiceWorker();
  requestNotificationPermission();
  